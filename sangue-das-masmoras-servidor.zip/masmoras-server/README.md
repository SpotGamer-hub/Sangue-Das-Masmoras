# Sangue das Masmoras — Servidor

Backend completo do jogo: contas, perfis salvos na nuvem, **placar global**,
**placar de clãs**, sistema de clãs (Rei / Conselheiro / Membro) e **chat de
clã em tempo real**.

## O que tem aqui

```
masmoras-server/
├── server/
│   ├── index.js          # servidor Express + Socket.IO
│   ├── db.js              # banco SQLite (cria o arquivo data.sqlite sozinho)
│   ├── auth.js             # autenticação JWT
│   └── routes/
│       ├── auth.js         # registro, login, perfil (autosave)
│       ├── clans.js        # clãs, papéis, convites, sugestões, chat
│       └── leaderboard.js  # placar global e placar de clãs
├── public/
│   └── index.html          # o JOGO em si (o arquivo que você já tinha)
└── package.json
```

O jogo (`public/index.html`) fala com esse servidor por HTTP (`fetch`) e por
WebSocket (chat do clã, via Socket.IO). Como o HTML é servido pela mesma
pasta `public/`, tudo funciona no mesmo domínio — sem configurar CORS nem
apontar URLs manualmente.

## Rodando localmente (teste)

```bash
cd masmoras-server
npm install
npm start
```

Abra `http://localhost:3000` no navegador. O banco de dados (`data.sqlite`)
é criado automaticamente na primeira execução, na raiz do projeto.

## Colocando no ar de verdade (produção)

Qualquer serviço que rode Node.js funciona. Alguns caminhos simples:

### Opção A — Railway / Render / Fly.io (mais fácil)
1. Suba esta pasta inteira num repositório Git (GitHub, por exemplo).
2. Crie um novo serviço "Web Service" apontando pro repositório.
3. Comando de build: `npm install`
4. Comando de start: `npm start`
5. Defina a variável de ambiente `JWT_SECRET` com um valor aleatório e
   secreto (ex: gere um com `openssl rand -hex 32`).
6. O serviço vai te dar uma URL pública (tipo `https://seujogo.up.railway.app`)
   — é isso que você compartilha com os jogadores.

**Atenção ao disco:** o banco SQLite (`data.sqlite`) precisa estar num disco
que **persista** entre deploys (a maioria desses serviços tem "Volumes" ou
"Persistent Disk" — ative isso e aponte pra pasta do projeto, senão o
progresso de todo mundo some a cada novo deploy).

### Opção B — VPS próprio (DigitalOcean, Hetzner, sua própria máquina)
```bash
git clone <seu-repositorio>
cd masmoras-server
npm install
npm install -g pm2          # mantém o servidor rodando e reinicia sozinho
JWT_SECRET=$(openssl rand -hex 32) pm2 start server/index.js --name masmoras
pm2 save
```
Depois configure um proxy reverso (nginx/Caddy) com HTTPS na frente da porta
3000, e aponte seu domínio pra ele.

### Variáveis de ambiente
- `PORT` — porta do servidor (padrão 3000)
- `JWT_SECRET` — **troque isso em produção**. É a chave que assina os tokens
  de login; se vazar, alguém pode forjar sessões de outros jogadores.

## Como o jogo usa isso

- **Contas e senha**: ficam só no servidor (senha nunca é salva em texto
  puro — é criptografada com bcrypt).
- **Progresso (perfil)**: o jogo manda o save pro servidor automaticamente
  a cada poucas ações (`PUT /api/auth/me`), com um cache local de segurança
  caso a internet caia no meio de uma sessão.
- **Placar global**: `GET /api/leaderboard` — todo jogador cadastrado no
  servidor aparece, não importa de que dispositivo ele jogou.
- **Clãs**: criar, convidar, promover a Conselheiro, expulsar, silenciar,
  editar nome/brasão/descrição/fundo — tudo pelo botão "🛡️ Clã" no menu.
  - **Rei** (quem criou o clã, nome em vermelho): pode tudo — editar o clã,
    convidar, promover 1 Conselheiro, apagar mensagens, expulsar, silenciar,
    dissolver o clã.
  - **Conselheiro** (nome em verde): não age direto — ele *sugere* ao Rei
    (convidar alguém, expulsar alguém, apagar uma mensagem, trocar a
    imagem do clã), e essas sugestões aparecem numa caixa de aprovação
    pro Rei aceitar ou recusar.
  - **Membro**: participa do chat, vê o placar interno do clã, pode sair
    quando quiser.
- **Placar de clãs**: `GET /api/leaderboard/clans` — soma a "melhor sala"
  de todos os membros de cada clã pra ranquear os clãs entre si.
- **Chat do clã**: tempo real via WebSocket, só entre membros do mesmo clã.

## Backup do banco

O arquivo `data.sqlite` (e `data.sqlite-wal` / `data.sqlite-shm`, que o
SQLite cria do lado) é **todo o progresso de todos os jogadores**. Faça
backup dele periodicamente (é só copiar o arquivo).
