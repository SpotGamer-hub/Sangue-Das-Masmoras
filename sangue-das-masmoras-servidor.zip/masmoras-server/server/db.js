const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '..', 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  username        TEXT PRIMARY KEY,
  password_hash   TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  profile_json    TEXT NOT NULL,      -- todo o resto do save (personagens, inventário, stats, etc)
  best_room       INTEGER DEFAULT 0,  -- coluna espelhada de profile.bestRoom, só pra ordenar rápido no placar
  xp              INTEGER DEFAULT 0,  -- coluna espelhada de profile.xp
  avatar_json     TEXT DEFAULT NULL,  -- coluna espelhada de profile.avatar, pro placar não precisar carregar o save inteiro
  clan_id         INTEGER REFERENCES clans(id) ON DELETE SET NULL,
  clan_role       TEXT DEFAULT NULL,  -- 'rei' | 'conselheiro' | 'membro'
  clan_muted      INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS clans (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL UNIQUE,
  description     TEXT DEFAULT '',
  banner_emoji    TEXT DEFAULT '🛡️',   -- brasão (símbolo)
  banner_color    TEXT DEFAULT '#8a1f1f',
  bg_color_1      TEXT DEFAULT '#1a0f0f', -- fundo do clã: cor 1 (gradiente)
  bg_color_2      TEXT DEFAULT '#3a1414', -- fundo do clã: cor 2 (gradiente)
  king            TEXT NOT NULL REFERENCES users(username),
  created_at      INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS clan_messages (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  clan_id         INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  author          TEXT NOT NULL,
  role            TEXT NOT NULL,       -- papel do autor no momento do envio (pra colorir o nome)
  text            TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  deleted         INTEGER DEFAULT 0
);

-- Sugestões que o Conselheiro manda pro Rei aprovar/rejeitar
CREATE TABLE IF NOT EXISTS clan_suggestions (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  clan_id         INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  author          TEXT NOT NULL,               -- sempre o conselheiro
  type            TEXT NOT NULL,               -- 'invite' | 'kick' | 'delete_message' | 'change_image'
  payload_json    TEXT NOT NULL,               -- detalhes (ex: {"username":"fulano"} ou {"messageId":5} ou {"banner_emoji":"🐺"})
  status          TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'approved' | 'rejected'
  created_at      INTEGER NOT NULL
);

-- Convites pendentes pro clã (o Rei convida, jogador aceita/recusa)
CREATE TABLE IF NOT EXISTS clan_invites (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  clan_id         INTEGER NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  username        TEXT NOT NULL,
  created_at      INTEGER NOT NULL,
  UNIQUE(clan_id, username)
);
`);

module.exports = db;
