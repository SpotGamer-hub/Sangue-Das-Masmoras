const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

const db = require('./db');
const { JWT_SECRET } = require('./auth');
const authRoutes = require('./routes/auth');
const leaderboardRoutes = require('./routes/leaderboard');
const clanRoutes = require('./routes/clans');

const PORT = process.env.PORT || 3000;

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

// injeta o socket.io nas rotas REST (pra elas conseguirem emitir eventos, ex: apagar mensagem)
app.use((req, res, next) => { req.io = io; next(); });

app.use('/api/auth', authRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/clans', clanRoutes);

app.use(express.static(path.join(__dirname, '..', 'public')));

/* ============================ CHAT (Socket.IO) ============================
   Cada clã tem uma "sala" (clan:<id>). Só quem é membro do clã consegue
   entrar/enviar mensagem. Silenciados (clan_muted) não conseguem enviar.
============================================================================ */
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('Não autenticado.'));
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.username = decoded.username;
    next();
  } catch (e) {
    next(new Error('Sessão inválida.'));
  }
});

io.on('connection', (socket) => {
  socket.on('clan:join', () => {
    const u = db.prepare('SELECT clan_id, clan_role, clan_muted FROM users WHERE username = ?').get(socket.username);
    if (!u || !u.clan_id) return socket.emit('clan:error', 'Você não está em um clã.');
    socket.join('clan:' + u.clan_id);
    socket.clanId = u.clan_id;
  });

  socket.on('clan:message', (text) => {
    const u = db.prepare('SELECT clan_id, clan_role, clan_muted FROM users WHERE username = ?').get(socket.username);
    if (!u || !u.clan_id) return socket.emit('clan:error', 'Você não está em um clã.');
    if (u.clan_muted) return socket.emit('clan:error', 'Você está silenciado no chat do clã.');
    const clean = String(text || '').slice(0, 300).trim();
    if (!clean) return;
    const info = db.prepare(
      `INSERT INTO clan_messages (clan_id, author, role, text, created_at) VALUES (?, ?, ?, ?, ?)`
    ).run(u.clan_id, socket.username, u.clan_role || 'membro', clean, Date.now());
    io.to('clan:' + u.clan_id).emit('clan:message', {
      id: info.lastInsertRowid, author: socket.username, role: u.clan_role || 'membro',
      text: clean, created_at: Date.now()
    });
  });
});

server.listen(PORT, () => {
  console.log(`Sangue das Masmoras — servidor rodando na porta ${PORT}`);
});
