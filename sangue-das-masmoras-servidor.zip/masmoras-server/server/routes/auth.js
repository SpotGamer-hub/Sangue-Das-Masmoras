const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { makeToken, requireAuth } = require('../auth');

const router = express.Router();

const USERNAME_RE = /^[A-Za-z0-9_À-ÿ ]{3,20}$/;

function defaultProfileJSON(username) {
  // Formato mínimo; o cliente já sabe migrar/preencher o resto (ensureProfileFields)
  return JSON.stringify({
    level: 1, xp: 0, skillPoints: 0, bestRoom: 0,
    stats: { enemiesKilled: 0, itemsCollected: 0, deaths: 0, shopPurchases: 0, dungeonsExplored: 0, playTimeMs: 0 },
    inventory: [], equipped: {}, playerCharacters: { active: 'cavaleiro', levels: {} },
    avatar: null
  });
}

router.post('/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Preencha nome e senha.' });
  if (!USERNAME_RE.test(username)) return res.status(400).json({ error: 'Nome deve ter 3-20 caracteres (letras, números, espaço, _).' });
  if (String(password).length < 4) return res.status(400).json({ error: 'Senha muito curta (mínimo 4 caracteres).' });

  const exists = db.prepare('SELECT username FROM users WHERE username = ?').get(username);
  if (exists) return res.status(409).json({ error: 'Esse nome já está em uso.' });

  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`INSERT INTO users (username, password_hash, created_at, profile_json, clan_role)
              VALUES (?, ?, ?, ?, NULL)`)
    .run(username, hash, Date.now(), defaultProfileJSON(username));

  res.json({ token: makeToken(username), username });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const row = db.prepare('SELECT * FROM users WHERE username = ?').get(username || '');
  if (!row || !bcrypt.compareSync(password || '', row.password_hash)) {
    return res.status(401).json({ error: 'Nome ou senha incorretos.' });
  }
  res.json({ token: makeToken(row.username), username: row.username });
});

// Retorna o save completo do jogador logado
router.get('/me', requireAuth, (req, res) => {
  const row = db.prepare('SELECT username, profile_json, clan_id, clan_role, clan_muted FROM users WHERE username = ?').get(req.username);
  if (!row) return res.status(404).json({ error: 'Perfil não encontrado.' });
  res.json({
    username: row.username,
    profile: JSON.parse(row.profile_json),
    clanId: row.clan_id,
    clanRole: row.clan_role,
    clanMuted: !!row.clan_muted
  });
});

// Sobrescreve o save do jogador logado (autosave do cliente)
router.put('/me', requireAuth, (req, res) => {
  const { profile } = req.body || {};
  if (!profile || typeof profile !== 'object') return res.status(400).json({ error: 'Perfil inválido.' });
  const avatar = { bg: profile.equippedBackground || 'bg_01', ch: profile.equippedCharacter || 'char_01' };
  db.prepare('UPDATE users SET profile_json = ?, best_room = ?, xp = ?, avatar_json = ? WHERE username = ?')
    .run(JSON.stringify(profile), profile.bestRoom || 0, profile.xp || 0, JSON.stringify(avatar), req.username);
  res.json({ ok: true });
});

// Perfil público de qualquer jogador (pra abrir o modal de perfil clicando no nome)
router.get('/profile/:username', (req, res) => {
  const row = db.prepare('SELECT username, profile_json, clan_id, clan_role FROM users WHERE username = ?').get(req.params.username);
  if (!row) return res.status(404).json({ error: 'Jogador não encontrado.' });
  let clanName = null;
  if (row.clan_id) {
    const c = db.prepare('SELECT name FROM clans WHERE id = ?').get(row.clan_id);
    clanName = c ? c.name : null;
  }
  res.json({ username: row.username, profile: JSON.parse(row.profile_json), clanId: row.clan_id, clanRole: row.clan_role, clanName });
});

module.exports = router;
