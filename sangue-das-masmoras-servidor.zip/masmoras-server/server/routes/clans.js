const express = require('express');
const db = require('../db');
const { requireAuth } = require('../auth');

const router = express.Router();

function getUser(username) {
  return db.prepare('SELECT * FROM users WHERE username = ?').get(username);
}
function getClan(id) {
  return db.prepare('SELECT * FROM clans WHERE id = ?').get(id);
}
function clanPublicView(clan) {
  const members = db.prepare(
    `SELECT username, clan_role, clan_muted, best_room, xp FROM users WHERE clan_id = ? ORDER BY
     CASE clan_role WHEN 'rei' THEN 0 WHEN 'conselheiro' THEN 1 ELSE 2 END, best_room DESC`
  ).all(clan.id);
  return {
    id: clan.id, name: clan.name, description: clan.description,
    bannerEmoji: clan.banner_emoji, bannerColor: clan.banner_color,
    bgColor1: clan.bg_color_1, bgColor2: clan.bg_color_2,
    king: clan.king, createdAt: clan.created_at,
    members
  };
}

// Middleware: garante que o usuário logado é membro do clã :id da rota
function requireMember(req, res, next) {
  const u = getUser(req.username);
  if (!u || String(u.clan_id) !== String(req.params.id)) {
    return res.status(403).json({ error: 'Você não é membro deste clã.' });
  }
  req.clanUser = u;
  next();
}
function requireKing(req, res, next) {
  const u = getUser(req.username);
  if (!u || String(u.clan_id) !== String(req.params.id) || u.clan_role !== 'rei') {
    return res.status(403).json({ error: 'Só o Rei do clã pode fazer isso.' });
  }
  req.clanUser = u;
  next();
}
function requireConselheiro(req, res, next) {
  const u = getUser(req.username);
  if (!u || String(u.clan_id) !== String(req.params.id) || u.clan_role !== 'conselheiro') {
    return res.status(403).json({ error: 'Só o Conselheiro pode sugerir isso.' });
  }
  req.clanUser = u;
  next();
}

/* ---------------------------- Consulta ---------------------------- */

router.get('/', (req, res) => {
  const q = (req.query.q || '').trim();
  const rows = q
    ? db.prepare('SELECT id, name, banner_emoji, banner_color FROM clans WHERE name LIKE ? ORDER BY name LIMIT 30').all('%' + q + '%')
    : db.prepare('SELECT id, name, banner_emoji, banner_color FROM clans ORDER BY name LIMIT 30').all();
  res.json({ clans: rows });
});

router.get('/:id', (req, res) => {
  const clan = getClan(req.params.id);
  if (!clan) return res.status(404).json({ error: 'Clã não encontrado.' });
  res.json(clanPublicView(clan));
});

router.get('/:id/messages', requireAuth, requireMember, (req, res) => {
  const rows = db.prepare(
    `SELECT id, author, role, text, created_at, deleted FROM clan_messages
     WHERE clan_id = ? ORDER BY id DESC LIMIT 100`
  ).all(req.params.id);
  res.json({ messages: rows.reverse() });
});

/* ------------------------------ Criar ------------------------------ */

router.post('/', requireAuth, (req, res) => {
  const u = getUser(req.username);
  if (u.clan_id) return res.status(400).json({ error: 'Você já está em um clã. Saia dele antes de criar outro.' });

  const { name, description, bannerEmoji, bannerColor, bgColor1, bgColor2 } = req.body || {};
  if (!name || name.trim().length < 3 || name.trim().length > 24) {
    return res.status(400).json({ error: 'Nome do clã deve ter 3-24 caracteres.' });
  }
  const exists = db.prepare('SELECT id FROM clans WHERE name = ?').get(name.trim());
  if (exists) return res.status(409).json({ error: 'Já existe um clã com esse nome.' });

  const info = db.prepare(
    `INSERT INTO clans (name, description, banner_emoji, banner_color, bg_color_1, bg_color_2, king, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    name.trim(), (description || '').slice(0, 200),
    bannerEmoji || '🛡️', bannerColor || '#8a1f1f',
    bgColor1 || '#1a0f0f', bgColor2 || '#3a1414',
    req.username, Date.now()
  );
  db.prepare('UPDATE users SET clan_id = ?, clan_role = ?, clan_muted = 0 WHERE username = ?')
    .run(info.lastInsertRowid, 'rei', req.username);

  res.json(clanPublicView(getClan(info.lastInsertRowid)));
});

/* ------------------------- Editar (Rei) ------------------------- */

router.put('/:id', requireAuth, requireKing, (req, res) => {
  const clan = getClan(req.params.id);
  const { name, description, bannerEmoji, bannerColor, bgColor1, bgColor2 } = req.body || {};
  const newName = name && name.trim() ? name.trim() : clan.name;
  if (newName !== clan.name) {
    const exists = db.prepare('SELECT id FROM clans WHERE name = ? AND id != ?').get(newName, clan.id);
    if (exists) return res.status(409).json({ error: 'Já existe um clã com esse nome.' });
  }
  db.prepare(
    `UPDATE clans SET name=?, description=?, banner_emoji=?, banner_color=?, bg_color_1=?, bg_color_2=? WHERE id=?`
  ).run(
    newName,
    description !== undefined ? String(description).slice(0, 200) : clan.description,
    bannerEmoji || clan.banner_emoji, bannerColor || clan.banner_color,
    bgColor1 || clan.bg_color_1, bgColor2 || clan.bg_color_2,
    clan.id
  );
  res.json(clanPublicView(getClan(clan.id)));
});

/* --------------------------- Convites --------------------------- */

// Rei convida diretamente
router.post('/:id/invite', requireAuth, requireKing, (req, res) => {
  const { username } = req.body || {};
  const target = getUser(username || '');
  if (!target) return res.status(404).json({ error: 'Jogador não encontrado.' });
  if (target.clan_id) return res.status(400).json({ error: 'Esse jogador já está em um clã.' });
  try {
    db.prepare('INSERT INTO clan_invites (clan_id, username, created_at) VALUES (?, ?, ?)')
      .run(req.params.id, target.username, Date.now());
  } catch (e) { /* já convidado (UNIQUE) — ignora */ }
  res.json({ ok: true });
});

router.get('/invites/mine', requireAuth, (req, res) => {
  const rows = db.prepare(
    `SELECT ci.id, ci.clan_id, c.name, c.banner_emoji, c.banner_color, ci.created_at
     FROM clan_invites ci JOIN clans c ON c.id = ci.clan_id WHERE ci.username = ?`
  ).all(req.username);
  res.json({ invites: rows });
});

router.post('/invites/:inviteId/accept', requireAuth, (req, res) => {
  const invite = db.prepare('SELECT * FROM clan_invites WHERE id = ? AND username = ?').get(req.params.inviteId, req.username);
  if (!invite) return res.status(404).json({ error: 'Convite não encontrado.' });
  const u = getUser(req.username);
  if (u.clan_id) return res.status(400).json({ error: 'Você já está em um clã.' });
  db.prepare('UPDATE users SET clan_id = ?, clan_role = ?, clan_muted = 0 WHERE username = ?')
    .run(invite.clan_id, 'membro', req.username);
  db.prepare('DELETE FROM clan_invites WHERE username = ?').run(req.username); // limpa outros convites pendentes
  res.json(clanPublicView(getClan(invite.clan_id)));
});

router.post('/invites/:inviteId/decline', requireAuth, (req, res) => {
  db.prepare('DELETE FROM clan_invites WHERE id = ? AND username = ?').run(req.params.inviteId, req.username);
  res.json({ ok: true });
});

/* ---------------------- Ações diretas do Rei ---------------------- */

router.post('/:id/kick', requireAuth, requireKing, (req, res) => {
  const { username } = req.body || {};
  if (username === req.username) return res.status(400).json({ error: 'O Rei não pode se expulsar. Use dissolver o clã.' });
  const target = getUser(username || '');
  if (!target || String(target.clan_id) !== String(req.params.id)) return res.status(404).json({ error: 'Esse jogador não é membro deste clã.' });
  db.prepare('UPDATE users SET clan_id = NULL, clan_role = NULL, clan_muted = 0 WHERE username = ?').run(target.username);
  req.io?.to('clan:' + req.params.id).emit('clan:memberRemoved', { username: target.username });
  res.json({ ok: true });
});

router.post('/:id/mute', requireAuth, requireKing, (req, res) => {
  const { username, muted } = req.body || {};
  const target = getUser(username || '');
  if (!target || String(target.clan_id) !== String(req.params.id)) return res.status(404).json({ error: 'Esse jogador não é membro deste clã.' });
  if (target.clan_role === 'rei') return res.status(400).json({ error: 'Não dá pra silenciar o Rei.' });
  db.prepare('UPDATE users SET clan_muted = ? WHERE username = ?').run(muted ? 1 : 0, target.username);
  res.json({ ok: true });
});

router.post('/:id/promote', requireAuth, requireKing, (req, res) => {
  const { username } = req.body || {};
  const target = getUser(username || '');
  if (!target || String(target.clan_id) !== String(req.params.id)) return res.status(404).json({ error: 'Esse jogador não é membro deste clã.' });
  // só 1 conselheiro por vez — rebaixa o atual, se houver
  db.prepare(`UPDATE users SET clan_role = 'membro' WHERE clan_id = ? AND clan_role = 'conselheiro'`).run(req.params.id);
  db.prepare(`UPDATE users SET clan_role = 'conselheiro' WHERE username = ?`).run(target.username);
  res.json({ ok: true });
});

router.post('/:id/demote', requireAuth, requireKing, (req, res) => {
  const { username } = req.body || {};
  const target = getUser(username || '');
  if (!target || String(target.clan_id) !== String(req.params.id)) return res.status(404).json({ error: 'Esse jogador não é membro deste clã.' });
  db.prepare(`UPDATE users SET clan_role = 'membro' WHERE username = ? AND clan_role = 'conselheiro'`).run(target.username);
  res.json({ ok: true });
});

router.post('/:id/leave', requireAuth, requireMember, (req, res) => {
  if (req.clanUser.clan_role === 'rei') {
    return res.status(400).json({ error: 'O Rei não pode sair — dissolva o clã ou promova alguém e transfira o trono (não implementado ainda).' });
  }
  db.prepare('UPDATE users SET clan_id = NULL, clan_role = NULL, clan_muted = 0 WHERE username = ?').run(req.username);
  res.json({ ok: true });
});

router.post('/:id/disband', requireAuth, requireKing, (req, res) => {
  db.prepare('UPDATE users SET clan_id = NULL, clan_role = NULL, clan_muted = 0 WHERE clan_id = ?').run(req.params.id);
  db.prepare('DELETE FROM clans WHERE id = ?').run(req.params.id);
  req.io?.to('clan:' + req.params.id).emit('clan:disbanded', {});
  res.json({ ok: true });
});

// Rei apaga mensagem diretamente
router.post('/:id/messages/:msgId/delete', requireAuth, requireKing, (req, res) => {
  db.prepare('UPDATE clan_messages SET deleted = 1 WHERE id = ? AND clan_id = ?').run(req.params.msgId, req.params.id);
  req.io?.to('clan:' + req.params.id).emit('clan:messageDeleted', { id: Number(req.params.msgId) });
  res.json({ ok: true });
});

/* ------------------ Sugestões do Conselheiro ------------------ */
// O Conselheiro NUNCA age direto — ele só sugere, e o Rei aprova/rejeita.

router.post('/:id/suggestions', requireAuth, requireConselheiro, (req, res) => {
  const { type, payload } = req.body || {};
  const validTypes = ['invite', 'kick', 'delete_message', 'change_image'];
  if (!validTypes.includes(type)) return res.status(400).json({ error: 'Tipo de sugestão inválido.' });
  const info = db.prepare(
    `INSERT INTO clan_suggestions (clan_id, author, type, payload_json, created_at) VALUES (?, ?, ?, ?, ?)`
  ).run(req.params.id, req.username, type, JSON.stringify(payload || {}), Date.now());
  req.io?.to('clan:' + req.params.id).emit('clan:newSuggestion', { id: info.lastInsertRowid });
  res.json({ ok: true, id: info.lastInsertRowid });
});

router.get('/:id/suggestions', requireAuth, requireMember, (req, res) => {
  // Rei vê tudo pendente; Conselheiro vê as próprias
  const rows = req.clanUser.clan_role === 'rei'
    ? db.prepare(`SELECT * FROM clan_suggestions WHERE clan_id = ? AND status='pending' ORDER BY id DESC`).all(req.params.id)
    : db.prepare(`SELECT * FROM clan_suggestions WHERE clan_id = ? AND author = ? ORDER BY id DESC LIMIT 20`).all(req.params.id, req.username);
  res.json({ suggestions: rows.map(r => ({ ...r, payload: JSON.parse(r.payload_json) })) });
});

router.post('/:id/suggestions/:sid/approve', requireAuth, requireKing, (req, res) => {
  const sug = db.prepare('SELECT * FROM clan_suggestions WHERE id = ? AND clan_id = ? AND status = ?').get(req.params.sid, req.params.id, 'pending');
  if (!sug) return res.status(404).json({ error: 'Sugestão não encontrada ou já resolvida.' });
  const payload = JSON.parse(sug.payload_json);

  if (sug.type === 'invite' && payload.username) {
    const target = getUser(payload.username);
    if (target && !target.clan_id) {
      try {
        db.prepare('INSERT INTO clan_invites (clan_id, username, created_at) VALUES (?, ?, ?)')
          .run(req.params.id, target.username, Date.now());
      } catch (e) {}
    }
  } else if (sug.type === 'kick' && payload.username) {
    const target = getUser(payload.username);
    if (target && String(target.clan_id) === String(req.params.id) && target.clan_role !== 'rei') {
      db.prepare('UPDATE users SET clan_id = NULL, clan_role = NULL, clan_muted = 0 WHERE username = ?').run(target.username);
      req.io?.to('clan:' + req.params.id).emit('clan:memberRemoved', { username: target.username });
    }
  } else if (sug.type === 'delete_message' && payload.messageId) {
    db.prepare('UPDATE clan_messages SET deleted = 1 WHERE id = ? AND clan_id = ?').run(payload.messageId, req.params.id);
    req.io?.to('clan:' + req.params.id).emit('clan:messageDeleted', { id: payload.messageId });
  } else if (sug.type === 'change_image' && (payload.bannerEmoji || payload.bannerColor || payload.bgColor1 || payload.bgColor2)) {
    const clan = getClan(req.params.id);
    db.prepare('UPDATE clans SET banner_emoji=?, banner_color=?, bg_color_1=?, bg_color_2=? WHERE id=?').run(
      payload.bannerEmoji || clan.banner_emoji, payload.bannerColor || clan.banner_color,
      payload.bgColor1 || clan.bg_color_1, payload.bgColor2 || clan.bg_color_2, clan.id
    );
  }

  db.prepare(`UPDATE clan_suggestions SET status = 'approved' WHERE id = ?`).run(sug.id);
  res.json({ ok: true });
});

router.post('/:id/suggestions/:sid/reject', requireAuth, requireKing, (req, res) => {
  db.prepare(`UPDATE clan_suggestions SET status = 'rejected' WHERE id = ? AND clan_id = ?`).run(req.params.sid, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
