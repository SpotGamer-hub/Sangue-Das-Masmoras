const express = require('express');
const db = require('../db');
const router = express.Router();

// Placar global: todo jogador cadastrado no servidor, não importa de onde ele se cadastrou
router.get('/', (req, res) => {
  const rows = db.prepare(`
    SELECT u.username, u.best_room, u.xp, u.avatar_json, u.clan_id, c.name AS clan_name
    FROM users u LEFT JOIN clans c ON c.id = u.clan_id
    ORDER BY u.best_room DESC, u.xp DESC
    LIMIT 100
  `).all();
  res.json({
    entries: rows.map(r => ({ ...r, avatar: r.avatar_json ? JSON.parse(r.avatar_json) : null }))
  });
});

// Placar de clãs: soma o "melhor room" (recorde) de todos os membros de cada clã
router.get('/clans', (req, res) => {
  const rows = db.prepare(`
    SELECT c.id, c.name, c.banner_emoji, c.banner_color, c.king,
           COUNT(u.username) AS member_count,
           COALESCE(SUM(u.best_room), 0) AS total_record,
           COALESCE(SUM(u.xp), 0) AS total_xp
    FROM clans c
    LEFT JOIN users u ON u.clan_id = c.id
    GROUP BY c.id
    ORDER BY total_record DESC, total_xp DESC
    LIMIT 100
  `).all();
  res.json({ entries: rows });
});

module.exports = router;
